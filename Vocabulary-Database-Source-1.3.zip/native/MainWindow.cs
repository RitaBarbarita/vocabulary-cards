using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;

namespace Vocab
{
    public sealed class MainWindow : RetroWindow
    {
        public readonly Store Store;
        readonly ContentControl view = new ContentControl();
        readonly StackPanel sidebar = new StackPanel();
        readonly TextBlock status = Retro.Text("");
        ScrollViewer cardScroll;
        CenteredCardsPanel cardItems;
        Button moreCards, backToTop;
        readonly TextBox search = new TextBox
        {
            Width = 160,
            Tag = "Search…",
            Margin = new Thickness(0, 0, 6, 0)
        };
        readonly ComboBox level = new ComboBox
        {
            Width = 95,
            Margin = new Thickness(0, 0, 5, 0)
        }, state = new ComboBox
        {
            Width = 100,
            Margin = new Thickness(0, 0, 5, 0)
        };
        readonly CheckBox favorite = new CheckBox
        {
            Content = "Favorites"
        };
        readonly WrapPanel filters = new WrapPanel
        {
            Margin = new Thickness(7, 6, 7, 6)
        };
        string section = "", topic = "", current = "cards";
        int visible = 48;
        bool ready;
        public List<Card> Filtered
        {
            get
            {
                return Store.Filter(search.Text, level.SelectedIndex > 0 ? Convert.ToString(level.SelectedItem) : "", state.SelectedIndex > 0 ? Defaults.Statuses[state.SelectedIndex - 1] : "", favorite.IsChecked == true, section, topic);
            }
        }

        public MainWindow(Store store) : base(AppInfo.Name, 1220, 820, true)
        {
            Store = store;
            MinWidth = 620;
            MinHeight = 400;
            var panel = new DockPanel();
            var toolbar = new DockPanel
            {
                Margin = new Thickness(4, 3, 4, 3)
            };
            var left = Retro.Row(Retro.Button("Cards", "cards", () => Switch("cards")), Retro.Button("Table", "table", () => Switch("table")), Retro.Button("Flashcards", "flash", () => Switch("flash")));
            var add = Retro.Button("Add Card", "add", () => Edit(null));
            add.Background = new SolidColorBrush(Color.FromRgb(215, 223, 232));
            add.Padding = new Thickness(10, 3, 10, 3);
            var right = Retro.Row(Retro.Button("Import Cards", "import", () => Import()), Retro.Button("Export to Excel", "export", () => Export()), add);
            DockPanel.SetDock(right, Dock.Right);
            toolbar.Children.Add(right);
            toolbar.Children.Add(left);
            DockPanel.SetDock(toolbar, Dock.Top);
            panel.Children.Add(toolbar);
            level.Items.Add("All Levels");
            foreach (var v in Defaults.Levels.Skip(1))
                level.Items.Add(v);
            level.SelectedIndex = 0;
            foreach (var v in new[]
            {
                "All Statuses",
                "New",
                "Learning",
                "Known"
            })
                state.Items.Add(v);
            state.SelectedIndex = 0;
            filters.Children.Add(Retro.Icon("search"));
            filters.Children.Add(search);
            filters.Children.Add(level);
            filters.Children.Add(state);
            favorite.Content = Retro.Row(Retro.Icon("favorite"), Retro.Text("Favorites"));
            filters.Children.Add(favorite);
            filters.Children.Add(Retro.Button("Reset", "reset", () => Reset()));
            var filterFrame = Retro.Frame(filters, true);
            DockPanel.SetDock(filterFrame, Dock.Top);
            var footer = new DockPanel();
            var credit = new TextBlock
            {
                Name = "AppCredit",
                Text = "Version " + AppInfo.Version + "  ·  " + AppInfo.Contact,
                FontSize = 10,
                Foreground = Brushes.DimGray,
                Margin = new Thickness(8, 4, 8, 3),
                VerticalAlignment = VerticalAlignment.Center
            };
            DockPanel.SetDock(credit, Dock.Right);
            footer.Children.Add(credit);
            status.TextTrimming = TextTrimming.CharacterEllipsis;
            status.Margin = new Thickness(5, 3, 5, 3);
            footer.Children.Add(status);
            var bottom = Retro.Frame(footer, true);
            DockPanel.SetDock(bottom, Dock.Bottom);
            panel.Children.Add(bottom);
            var grid = new Grid
            {
                Margin = new Thickness(4, 4, 4, 4)
            };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(194) });
            var leftBody = new DockPanel
            {
                Margin = new Thickness(0, 0, 5, 0)
            };
            leftBody.Children.Add(filterFrame);
            view.Margin = new Thickness(0, 4, 0, 0);
            leftBody.Children.Add(view);
            grid.Children.Add(leftBody);
            var side = Retro.Frame(new ScrollViewer { Content = sidebar, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });
            Grid.SetColumn(side, 1);
            grid.Children.Add(side);
            panel.Children.Add(grid);
            Body = panel;
            search.TextChanged += (s, e) => Refresh();
            level.SelectionChanged += (s, e) => Refresh();
            state.SelectionChanged += (s, e) => Refresh();
            favorite.Checked += (s, e) => Refresh();
            favorite.Unchecked += (s, e) => Refresh();
            ready = true;
            Refresh();
            PreviewKeyDown += (s, e) =>
            {
                if (e.Key == Key.F && Keyboard.Modifiers == ModifierKeys.Control)
                {
                    search.Focus();
                    search.SelectAll();
                    e.Handled = true;
                }

                if (e.Key == Key.N && Keyboard.Modifiers == ModifierKeys.Control)
                {
                    Edit(null);
                    e.Handled = true;
                }
            };
        }

        public void Reset()
        {
            ready = false;
            search.Text = "";
            level.SelectedIndex = state.SelectedIndex = 0;
            favorite.IsChecked = false;
            section = topic = "";
            ready = true;
            Refresh();
        }

        public void Switch(string which)
        {
            current = which;
            Refresh();
        }

        public void Refresh()
        {
            Refresh(false);
        }

        void Refresh(bool preservePosition)
        {
            if (!ready)
                return;
            double offset = preservePosition && current == "cards" && cardScroll != null ? cardScroll.VerticalOffset : 0;
            var oldTable = preservePosition ? view.Content as DataGrid : null;
            var oldTableScroll = TableScroll(oldTable);
            double tableOffset = oldTableScroll == null ? 0 : oldTableScroll.VerticalOffset;
            double horizontalOffset = oldTableScroll == null ? 0 : oldTableScroll.HorizontalOffset;
            var selected = oldTable == null ? null : oldTable.SelectedItem as Card;
            var sorts = oldTable == null ? null : oldTable.Items.SortDescriptions.ToArray();
            if (!preservePosition)
                visible = 48;
            Render();
            BuildSidebar();
            if (preservePosition && current == "cards")
            {
                var target = cardScroll;
                target.UpdateLayout();
                target.ScrollToVerticalOffset(offset);
            }
            else if (oldTable != null)
            {
                var target = view.Content as DataGrid;
                if (target == null)
                    return;
                foreach (var sort in sorts)
                {
                    target.Items.SortDescriptions.Add(sort);
                    var column = target.Columns.OfType<DataGridTextColumn>().FirstOrDefault(c => ((Binding)c.Binding).Path.Path == sort.PropertyName);
                    if (column != null)
                        column.SortDirection = sort.Direction;
                }
                if (selected != null)
                    target.SelectedItem = Filtered.FirstOrDefault(c => c.id == selected.id);
                target.UpdateLayout();
                var targetScroll = TableScroll(target);
                if (targetScroll != null)
                {
                    targetScroll.ScrollToVerticalOffset(tableOffset);
                    targetScroll.ScrollToHorizontalOffset(horizontalOffset);
                }
            }
        }

        static ScrollViewer TableScroll(DependencyObject parent)
        {
            if (parent == null)
                return null;
            var scroll = parent as ScrollViewer;
            if (scroll != null)
                return scroll;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                scroll = TableScroll(VisualTreeHelper.GetChild(parent, i));
                if (scroll != null)
                    return scroll;
            }
            return null;
        }

        void Render()
        {
            if (current == "cards")
                RenderCards();
            else if (current == "table")
                RenderTable();
            else if (!(view.Content is FlashPanel))
                view.Content = new FlashPanel(Store);
            var cards = Filtered;
            status.Text = "Total: " + Store.Data.cards.Count + "    Shown: " + cards.Count + "    Favorites: " + Store.Data.cards.Count(c => c.favorite) + (section.Length > 0 ? "    Section: " + section : "") + (topic.Length > 0 ? "    Topic: " + topic : "");
        }

        public void Edit(Card card)
        {
            var w = new EditorWindow(Store, card)
            {
                Owner = this
            };
            w.ShowDialog();
            if (w.Saved)
                Refresh(true);
            else
                BuildSidebar();
        }

        public void Detail(Card card)
        {
            var w = new DetailWindow(Store, card)
            {
                Owner = this
            };
            w.EditRequested += () =>
            {
                w.Close();
                Edit(card);
            };
            w.ShowDialog();
        }

        void Delete(Card c)
        {
            if (!Retro.Confirm("Delete \"" + c.english + "\"?"))
                return;
            Store.Data.cards.Remove(c);
            Store.Save();
            Refresh(true);
        }

        void Fav(Card c)
        {
            c.favorite = !c.favorite;
            Store.Save();
            Refresh(true);
        }

        void RenderCards()
        {
            var stack = new StackPanel();
            cardItems = new CenteredCardsPanel
            {
                Margin = new Thickness(4),
                Name = "CardItems"
            };
            foreach (var c in Filtered.Take(visible))
                cardItems.Children.Add(CardTile(c));
            stack.Children.Add(cardItems);
            moreCards = Retro.Button("Show more", null, () => ShowMoreCards());
            moreCards.Name = "MoreCards";
            moreCards.Focusable = false;
            moreCards.HorizontalAlignment = HorizontalAlignment.Center;
            moreCards.Margin = new Thickness(10);
            moreCards.Visibility = Filtered.Count > visible ? Visibility.Visible : Visibility.Collapsed;
            stack.Children.Add(moreCards);
            if (Filtered.Count == 0)
                stack.Children.Add(new TextBlock { Text = Store.Data.cards.Count == 0 ? "No cards yet. Add your first word or phrase." : "No cards match the current filter.", HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(20) });
            cardScroll = new ScrollViewer
            {
                Name = "CardScroll",
                Content = stack,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled
            };
            backToTop = Retro.Button("Back to top", "up", () => cardScroll.ScrollToTop());
            backToTop.Name = "BackToTop";
            backToTop.HorizontalAlignment = HorizontalAlignment.Right;
            backToTop.VerticalAlignment = VerticalAlignment.Bottom;
            backToTop.Margin = new Thickness(12, 12, 25, 12);
            backToTop.Visibility = Visibility.Collapsed;
            cardScroll.ScrollChanged += (s, e) => backToTop.Visibility = cardScroll.VerticalOffset > 300 ? Visibility.Visible : Visibility.Collapsed;
            var browser = new Grid();
            browser.Children.Add(cardScroll);
            browser.Children.Add(backToTop);
            view.Content = Retro.Frame(browser, true);
        }

        public void ShowMoreCards()
        {
            if (cardItems == null || current != "cards")
                return;
            double offset = cardScroll.VerticalOffset;
            var list = Filtered;
            foreach (var c in list.Skip(cardItems.Children.Count).Take(48))
                cardItems.Children.Add(CardTile(c));
            visible = cardItems.Children.Count;
            moreCards.Visibility = list.Count > visible ? Visibility.Visible : Visibility.Collapsed;
            cardScroll.UpdateLayout();
            cardScroll.ScrollToVerticalOffset(offset);
        }

        Border CardTile(Card c)
        {
            var content = new StackPanel
            {
                Margin = new Thickness(7)
            };
            var title = new DockPanel();
            var star = Retro.Tiny("favorite", c.favorite ? "Remove favorite" : "Favorite", () => Fav(c));
            star.Template = (ControlTemplate)Application.Current.Resources["FlatButton"];
            star.Opacity = c.favorite ? 1 : .5;
            DockPanel.SetDock(star, Dock.Right);
            title.Children.Add(star);
            var word = Retro.Text(c.english, true, 12);
            title.Children.Add(word);
            content.Children.Add(title);
            content.Children.Add(new Border { BorderBrush = new SolidColorBrush(Color.FromRgb(210, 210, 210)), BorderThickness = new Thickness(0, 0, 0, 1), Margin = new Thickness(0, 4, 0, 4) });
            content.Children.Add(Retro.Text(c.russian));
            if (!String.IsNullOrEmpty(c.example))
            {
                var first = c.example.Split('\n')[0].Trim();
                if (first.Length > 90)
                    first = first.Substring(0, 87) + "…";
                content.Children.Add(new Border { Background = new SolidColorBrush(Color.FromRgb(244, 244, 255)), BorderBrush = Retro.Navy, BorderThickness = new Thickness(3, 0, 0, 0), Margin = new Thickness(0, 4, 0, 4), Child = new TextBlock { Text = first, FontSize = 11, FontStyle = FontStyles.Italic, Foreground = Retro.Navy, Margin = new Thickness(5, 1, 0, 1), TextWrapping = TextWrapping.Wrap } });
            }

            content.Children.Add(CardView.Tags(c));
            var actions = Retro.Row(Retro.Tiny("book", "Open", () => Detail(c)), Retro.Tiny("edit", "Edit", () => Edit(c)), Retro.Tiny("image", "Save card as PNG", () => CardView.Export(Store, c)), Retro.Tiny("delete", "Delete", () => Delete(c)));
            actions.Margin = new Thickness(0, 7, 0, 0);
            content.Children.Add(actions);
            if (c.attachments.Count > 0)
            {
                var images = new StackPanel
                {
                    Visibility = Visibility.Collapsed
                };
                var b = Retro.Button("Images (" + c.attachments.Count + ")", "attach", () =>
                {
                    if (images.Children.Count == 0)
                        foreach (var a in c.attachments)
                            images.Children.Add(CardView.Image(Store, a, 280));
                    images.Visibility = images.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
                });
                b.HorizontalAlignment = HorizontalAlignment.Left;
                b.Margin = new Thickness(0, 4, 0, 0);
                content.Children.Add(b);
                content.Children.Add(images);
            }

            var frame = Retro.Frame(content, false, Brushes.White);
            frame.Width = 335;
            frame.Margin = new Thickness(3.5, 0, 3.5, 7);
            frame.MouseLeftButtonDown += (s, e) =>
            {
                if (e.ClickCount == 2)
                    Detail(c);
            };
            return frame;
        }

        void RenderTable()
        {
            var table = new DataGrid
            {
                ItemsSource = Filtered,
                SelectionMode = DataGridSelectionMode.Single
            };
            foreach (var pair in new[]
            {
                new[]
                {
                    "english",
                    "Word or Phrase"
                },
                new[]
                {
                    "russian",
                    "Translation"
                },
                new[]
                {
                    "synonyms",
                    "Synonyms"
                },
                new[]
                {
                    "antonyms",
                    "Antonyms"
                },
                new[]
                {
                    "example",
                    "Example"
                },
                new[]
                {
                    "explanation",
                    "Explanation"
                },
                new[]
                {
                    "sections",
                    "Sections"
                },
                new[]
                {
                    "topics",
                    "Topics"
                },
                new[]
                {
                    "level",
                    "Level"
                },
                new[]
                {
                    "status",
                    "Status"
                }
            })
                table.Columns.Add(new DataGridTextColumn { Header = pair[1], Binding = new Binding(pair[0]) { Converter = new TableText() }, Width = pair[0] == "level" ? 55 : pair[0] == "status" ? 80 : 155 });
            var favoriteTemplate = new DataTemplate();
            var favoriteButton = new FrameworkElementFactory(typeof(Button));
            favoriteButton.SetValue(Button.ToolTipProperty, "Toggle favorite");
            favoriteButton.SetValue(Button.TemplateProperty, Application.Current.Resources["FlatButton"]);
            var favoriteImage = new FrameworkElementFactory(typeof(Image));
            favoriteImage.SetValue(Image.SourceProperty, Retro.Bitmap("favorite"));
            favoriteImage.SetValue(Image.WidthProperty, 16.0);
            favoriteImage.SetValue(Image.HeightProperty, 16.0);
            favoriteImage.SetBinding(Image.OpacityProperty, new Binding("favorite") { Converter = new FavoriteOpacity() });
            favoriteButton.AppendChild(favoriteImage);
            favoriteButton.AddHandler(Button.ClickEvent, new RoutedEventHandler((s, e) => Fav((Card)((FrameworkElement)s).DataContext)));
            favoriteTemplate.VisualTree = favoriteButton;
            table.Columns.Add(new DataGridTemplateColumn { Header = "Favorite", CellTemplate = favoriteTemplate, Width = 60 });
            var template = new DataTemplate();
            var row = new FrameworkElementFactory(typeof(StackPanel));
            row.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);
            foreach (var action in new[]
            {
                "book",
                "edit",
                "image",
                "delete"
            })
            {
                var b = new FrameworkElementFactory(typeof(Button));
                b.SetValue(Button.ToolTipProperty, action == "book" ? "Open" : action == "edit" ? "Edit" : action == "image" ? "Save PNG" : "Delete");
                b.SetValue(Button.PaddingProperty, new Thickness(3, 1, 0, 1));
                var image = new FrameworkElementFactory(typeof(Image));
                image.SetValue(Image.SourceProperty, Retro.Bitmap(action));
                image.SetValue(Image.WidthProperty, 16.0);
                image.SetValue(Image.HeightProperty, 16.0);
                image.SetValue(Image.MarginProperty, new Thickness(0, 0, 3, 0));
                b.AppendChild(image);
                var key = action;
                b.AddHandler(Button.ClickEvent, new RoutedEventHandler((s, e) =>
                {
                    var c = (Card)((FrameworkElement)s).DataContext;
                    if (key == "book")
                        Detail(c);
                    else if (key == "edit")
                        Edit(c);
                    else if (key == "image")
                        CardView.Export(Store, c);
                    else
                        Delete(c);
                }));
                row.AppendChild(b);
            }

            template.VisualTree = row;
            table.Columns.Add(new DataGridTemplateColumn { Header = "Actions", CellTemplate = template, Width = 120 });
            table.MouseDoubleClick += (s, e) =>
            {
                if (table.SelectedItem is Card)
                    Detail((Card)table.SelectedItem);
            };
            view.Content = table;
        }

        void BuildSidebar()
        {
            sidebar.Children.Clear();
            var title = Retro.Row(Retro.Icon("folder"), Retro.Text("Filter by Section / Topic", true, 11, Brushes.White));
            title.Background = Retro.Navy;
            title.Margin = new Thickness(2);
            sidebar.Children.Add(title);
            foreach (var kind in new[]
            {
                "section",
                "topic"
            })
            {
                var heading = new DockPanel
                {
                    Margin = new Thickness(5, 4, 4, 2)
                };
                var reset = Retro.Tiny("close", "Clear filter", () =>
                {
                    if (kind == "section")
                        section = "";
                    else
                        topic = "";
                    Refresh();
                });
                DockPanel.SetDock(reset, Dock.Right);
                heading.Children.Add(reset);
                heading.Children.Add(Retro.Text(kind == "section" ? "Sections" : "Topics", true, 11));
                sidebar.Children.Add(heading);
                var list = new StackPanel();
                foreach (var value in kind == "section" ? Store.Sections() : Store.Topics())
                {
                    var name = value;
                    var k = kind;
                    var row = new DockPanel
                    {
                        Margin = new Thickness(5, 0, 4, 0),
                        Background = (k == "section" ? section : topic) == name ? Retro.Navy : Brushes.Transparent
                    };
                    int count = Store.Data.cards.Count(c => (k == "section" ? c.sections : c.topics).Contains(name));
                    var n = Retro.Text(count.ToString(), false, 10, Brushes.Gray);
                    n.Margin = new Thickness(3, 0, 1, 0);
                    DockPanel.SetDock(n, Dock.Right);
                    row.Children.Add(n);
                    if (!(k == "section" ? Defaults.Sections : Defaults.Topics).Contains(name))
                    {
                        var del = Retro.Tiny("delete", "Delete", () => DeleteTag(k, name));
                        del.MinHeight = 16;
                        del.Height = 18;
                        del.Padding = new Thickness(1);
                        DockPanel.SetDock(del, Dock.Right);
                        row.Children.Add(del);
                    }

                    var text = Retro.Text(name, false, 11, (k == "section" ? section : topic) == name ? Brushes.White : Brushes.Black);
                    text.Margin = new Thickness(0, 3, 0, 3);
                    row.Children.Add(text);
                    text.MouseLeftButtonUp += (s, e) =>
                    {
                        if (k == "section")
                            section = section == name ? "" : name;
                        else
                            topic = topic == name ? "" : name;
                        Refresh();
                    };
                    list.Children.Add(row);
                }

                sidebar.Children.Add(new ScrollViewer { Content = list, Height = kind == "section" ? 250 : 240, VerticalScrollBarVisibility = ScrollBarVisibility.Auto });
                var input = new TextBox
                {
                    Width = 140,
                    MinHeight = 22,
                    Tag = kind == "section" ? "New section…" : "New topic…"
                };
                var type = kind;
                var add = Retro.Tiny("add", "Add", () =>
                {
                    var v = input.Text.Trim();
                    if (v.Length == 0)
                        return;
                    var values = type == "section" ? Store.Data.settings.customSections : Store.Data.settings.customTopics;
                    if (!(type == "section" ? Store.Sections() : Store.Topics()).Contains(v))
                        values.Add(v);
                    Store.Save();
                    Refresh();
                });
                var r = Retro.Row(input, add);
                r.Margin = new Thickness(4);
                sidebar.Children.Add(r);
            }
        }

        void DeleteTag(string kind, string name)
        {
            var used = Store.Data.cards.Where(c => (kind == "section" ? c.sections : c.topics).Contains(name)).ToList();
            if (used.Count > 0 && !Retro.Confirm("Delete \"" + name + "\" and remove it from " + used.Count + " card(s)?"))
                return;
            foreach (var c in used)
                (kind == "section" ? c.sections : c.topics).Remove(name);
            (kind == "section" ? Store.Data.settings.customSections : Store.Data.settings.customTopics).Remove(name);
            if (kind == "section" && section == name)
                section = "";
            if (kind == "topic" && topic == name)
                topic = "";
            Store.Save();
            Refresh();
        }

        void Import()
        {
            new ImportWindow(Store)
            {
                Owner = this
            }.ShowDialog();
            Refresh();
        }

        void Export()
        {
            var dialog = new SaveFileDialog
            {
                Filter = "Excel workbook (*.xlsx)|*.xlsx",
                FileName = "Vocabulary.xlsx"
            };
            if (dialog.ShowDialog(this) == true)
            {
                Tables.WriteXlsx(dialog.FileName, Tables.Export(Store.Data.cards));
                Retro.Message("Exported " + Store.Data.cards.Count + " cards.");
            }
        }
    }

    public sealed class TableText : IValueConverter
    {
        public object Convert(object value, Type target, object parameter, System.Globalization.CultureInfo culture)
        {
            var list = value as System.Collections.Generic.IEnumerable<string>;
            if (list != null)
                return String.Join("; ", list);
            var text = System.Convert.ToString(value);
            return Defaults.Statuses.Contains(text) ? Defaults.Status(text) : text;
        }

        public object ConvertBack(object value, Type target, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }

    public sealed class FavoriteOpacity : IValueConverter
    {
        public object Convert(object value, Type target, object parameter, System.Globalization.CultureInfo culture)
        {
            return value is bool && (bool)value ? 1.0 : .4;
        }

        public object ConvertBack(object value, Type target, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
