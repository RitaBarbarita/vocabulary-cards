using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace Vocab
{
    public sealed class FlashPanel : ContentControl
    {
        readonly Store store;
        readonly ComboBox topic = new ComboBox
        {
            Width = 280
        }, section = new ComboBox
        {
            Width = 280
        }, level = new ComboBox
        {
            Width = 280
        };
        readonly TextBlock count = Retro.Text("");
        string selectedStatus = "";
        List<Card> queue;
        int index;
        bool flipped;
        public FlashPanel(Store data)
        {
            store = data;
            Setup();
        }

        public List<Card> Pool()
        {
            return store.Filter("", level.SelectedIndex > 0 ? Convert.ToString(level.SelectedItem) : "", selectedStatus, false, section.SelectedIndex > 0 ? Convert.ToString(section.SelectedItem) : "", topic.SelectedIndex > 0 ? Convert.ToString(topic.SelectedItem) : "");
        }

        void Setup()
        {
            foreach (var element in new UIElement[]
            {
                topic,
                section,
                level,
                count
            })
            {
                var parent = ((FrameworkElement)element).Parent as Panel;
                if (parent != null)
                    parent.Children.Remove(element);
            }

            var panel = new StackPanel
            {
                Margin = new Thickness(14)
            };
            panel.Children.Add(Retro.Heading("Flashcard Session Setup", "flash"));
            if (topic.Items.Count == 0)
            {
                topic.Items.Add("All topics");
                foreach (var s in store.Topics())
                    topic.Items.Add(s);
                topic.SelectedIndex = 0;
                section.Items.Add("All sections");
                foreach (var s in store.Sections())
                    section.Items.Add(s);
                section.SelectedIndex = 0;
                level.Items.Add("All levels");
                foreach (var s in Defaults.Levels.Skip(1))
                    level.Items.Add(s);
                level.SelectedIndex = 0;
                foreach (var c in new[]
                {
                    topic,
                    section,
                    level
                })
                    c.SelectionChanged += (s, e) => count.Text = Pool().Count + " cards";
            }

            var options = new WrapPanel();
            options.Children.Add(new TextBlock { Text = "By status:", Width = 85, VerticalAlignment = VerticalAlignment.Center });
            var labels = new[]
            {
                "All",
                "Don't know",
                "Learning",
                "Know it"
            };
            var icons = new[]
            {
                "cards",
                "no",
                "learning",
                "yes"
            };
            for (int i = 0; i < labels.Length; i++)
            {
                string value = i == 0 ? "" : Defaults.Statuses[i - 1];
                var radio = new RadioButton
                {
                    Content = Retro.Row(Retro.Icon(icons[i]), Retro.Text(labels[i], false, 11)),
                    GroupName = "pool",
                    IsChecked = selectedStatus == value,
                    Margin = new Thickness(0, 3, 9, 3),
                    VerticalContentAlignment = VerticalAlignment.Center
                };
                radio.Checked += (s, e) =>
                {
                    selectedStatus = value;
                    count.Text = Pool().Count + " cards";
                };
                options.Children.Add(radio);
            }

            panel.Children.Add(options);
            foreach (var pair in new[]
            {
                Tuple.Create("By level:", level),
                Tuple.Create("By topic:", topic),
                Tuple.Create("By section:", section)
            })
            {
                var row = new DockPanel
                {
                    Margin = new Thickness(0, 9, 0, 0)
                };
                var label = Retro.Text(pair.Item1);
                label.Width = 85;
                row.Children.Add(label);
                row.Children.Add(pair.Item2);
                panel.Children.Add(row);
            }

            count.Text = Pool().Count + " cards";
            count.Margin = new Thickness(8, 0, 0, 0);
            var start = Retro.Button("Start", "play", () => Start(false));
            start.Background = new SolidColorBrush(Color.FromRgb(215, 223, 232));
            var actions = Retro.Row(start, Retro.Button("Shuffle & Start", "shuffle", () => Start(true)), count);
            actions.Margin = new Thickness(0, 12, 0, 0);
            panel.Children.Add(actions);
            Content = new Border
            {
                Child = Retro.Frame(panel, true),
                MaxWidth = 530,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(14, 26, 14, 0)
            };
        }

        public void Start(bool shuffle)
        {
            queue = Pool();
            if (queue.Count == 0)
            {
                Retro.Message("No cards match this selection.");
                return;
            }

            if (shuffle)
            {
                var r = new Random();
                for (int i = queue.Count - 1; i > 0; i--)
                {
                    int j = r.Next(i + 1);
                    var c = queue[i];
                    queue[i] = queue[j];
                    queue[j] = c;
                }
            }

            index = 0;
            flipped = false;
            Show();
        }

        public void Flip()
        {
            flipped = !flipped;
            Show();
        }

        public void Answer(string answer)
        {
            if (queue == null || index >= queue.Count)
                return;
            var c = store.Data.cards.FirstOrDefault(v => v.id == queue[index].id);
            if (c != null)
            {
                c.status = answer;
                store.Save();
            }

            index++;
            flipped = false;
            Show();
        }

        void Show()
        {
            var p = new StackPanel
            {
                Margin = new Thickness(25),
                MaxWidth = 620,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            var back = Retro.Button("Back", "back", () => Setup());
            back.HorizontalAlignment = HorizontalAlignment.Left;
            p.Children.Add(back);
            if (index >= queue.Count)
            {
                p.Children.Add(Retro.Heading("Session complete", "yes"));
                p.Children.Add(Retro.Text("You reviewed " + queue.Count + " cards."));
                p.Children.Add(Retro.Button("Practise again", "reset", () => Setup()));
                Content = p;
                return;
            }

            var c = queue[index];
            p.Children.Add(new TextBlock { Text = (index + 1) + " / " + queue.Count, Margin = new Thickness(0, 12, 0, 8), HorizontalAlignment = HorizontalAlignment.Center });
            var card = new StackPanel
            {
                Margin = new Thickness(25),
                MinWidth = 370,
                MinHeight = 190
            };
            card.Children.Add(new TextBlock { Text = flipped ? c.russian : c.english, FontWeight = FontWeights.Bold, FontSize = 24, TextWrapping = TextWrapping.Wrap, HorizontalAlignment = HorizontalAlignment.Center, TextAlignment = TextAlignment.Center, Foreground = flipped ? Retro.Navy : Brushes.Black });
            if (flipped)
                card.Children.Add(new TextBlock { Text = c.explanation, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 15, 0, 0), TextAlignment = TextAlignment.Center });
            else
                card.Children.Add(new TextBlock { Text = "Click to reveal", Foreground = Brushes.Gray, Margin = new Thickness(0, 22, 0, 0), HorizontalAlignment = HorizontalAlignment.Center });
            var frame = Retro.Frame(card, true, Brushes.White);
            frame.MouseLeftButtonUp += (s, e) => Flip();
            p.Children.Add(frame);
            if (flipped)
            {
                var actions = Retro.Row(Retro.Button("Don't know", "no", () => Answer("new")), Retro.Button("Almost", "learning", () => Answer("learning")), Retro.Button("Know it", "yes", () => Answer("known")));
                actions.Margin = new Thickness(0, 12, 0, 0);
                actions.HorizontalAlignment = HorizontalAlignment.Center;
                p.Children.Add(actions);
            }

            Content = p;
        }
    }

    public sealed class ImportWindow : RetroWindow
    {
        readonly Store store;
        readonly TextBox input = new TextBox
        {
            AcceptsReturn = true,
            TextWrapping = TextWrapping.NoWrap,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            FontFamily = new FontFamily("Consolas"),
            FontSize = 11,
            Height = 130
        };
        readonly StackPanel mapping = new StackPanel();
        readonly TextBlock status = Retro.Text("Paste a table or choose a file.");
        readonly CheckBox skip = new CheckBox
        {
            Content = "Skip cards whose Word or Phrase already exists",
            IsChecked = true
        };
        List<List<string>> rows = new List<List<string>>();
        readonly Dictionary<string, ComboBox> choices = new Dictionary<string, ComboBox>();
        bool updating;
        public ImportWindow(Store data) : base("Import Cards", 820, Math.Min(780, SystemParameters.WorkArea.Height - 30), true)
        {
            store = data;
            var dock = new DockPanel();
            var footer = Retro.Row(Retro.Button("Import", "import", () => RunImport()), Retro.Button("Cancel", null, () => Close()));
            footer.HorizontalAlignment = HorizontalAlignment.Right;
            footer.Margin = new Thickness(8);
            DockPanel.SetDock(footer, Dock.Bottom);
            dock.Children.Add(footer);
            var p = new StackPanel
            {
                Margin = new Thickness(10)
            };
            p.Children.Add(Retro.Text("Import a vocabulary table", true));
            p.Children.Add(new TextBlock { Text = "1. Put column names in the first row.\n2. Put one card in each row. Word or Phrase is required.\n3. Paste cells below or choose an Excel / CSV file.", LineHeight = 20, Margin = new Thickness(0, 4, 0, 8) });
            p.Children.Add(Retro.Row(Retro.Button("Download template", "document", () => DownloadTemplate()), Retro.Button("Choose Excel / CSV file", "folder", () => Choose())));
            input.Margin = new Thickness(0, 8, 0, 8);
            p.Children.Add(input);
            p.Children.Add(Retro.Frame(status, true));
            status.Margin = new Thickness(6);
            p.Children.Add(Retro.Heading("Match your columns"));
            p.Children.Add(mapping);
            p.Children.Add(skip);
            dock.Children.Add(new ScrollViewer { Content = p, VerticalScrollBarVisibility = ScrollBarVisibility.Auto });
            Body = dock;
            input.TextChanged += (s, e) =>
            {
                if (updating)
                    return;
                try
                {
                    rows = Tables.Parse(input.Text);
                    Render();
                }
                catch (Exception error)
                {
                    status.Text = error.Message;
                }
            };
        }

        void Choose()
        {
            var d = new OpenFileDialog
            {
                Filter = "Excel / text tables|*.xlsx;*.xls;*.csv;*.tsv;*.txt|All files|*.*"
            };
            if (d.ShowDialog(this) != true)
                return;
            rows = Tables.ReadFile(d.FileName);
            updating = true;
            input.Text = Tables.Tsv(rows);
            updating = false;
            Render();
        }

        void Render()
        {
            mapping.Children.Clear();
            choices.Clear();
            if (rows.Count == 0)
            {
                status.Text = "Paste a table or choose a file.";
                return;
            }

            var headers = rows[0];
            var automatic = Tables.Map(headers);
            for (int i = 0; i < Tables.Fields.Length; i++)
            {
                var row = new Grid
                {
                    Margin = new Thickness(0, 3, 0, 3)
                };
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(180) });
                row.ColumnDefinitions.Add(new ColumnDefinition());
                row.Children.Add(Retro.Text(Tables.Labels[i], i == 0));
                var c = new ComboBox();
                c.Items.Add("— Not imported —");
                for (int k = 0; k < headers.Count; k++)
                    c.Items.Add((k + 1) + ". " + headers[k]);
                c.SelectedIndex = automatic[i] + 1;
                Grid.SetColumn(c, 1);
                row.Children.Add(c);
                choices[Tables.Fields[i]] = c;
                mapping.Children.Add(row);
            }

            status.Text = (rows.Count - 1) + " rows · " + headers.Count + " columns";
        }

        void RunImport()
        {
            if (rows.Count < 2)
            {
                Retro.Message("Paste a header row and at least one card.");
                return;
            }

            int skipped;
            var result = Tables.Import(rows, Tables.Fields.Select(f => choices[f].SelectedIndex - 1).ToArray(), skip.IsChecked == true, store, out skipped);
            Retro.Message("Imported " + result.Count + " cards" + (skipped > 0 ? "; skipped " + skipped : "") + ".");
            Close();
        }

        void DownloadTemplate()
        {
            var d = new SaveFileDialog
            {
                Filter = "Excel workbook (*.xlsx)|*.xlsx",
                FileName = "Vocabulary-template.xlsx"
            };
            if (d.ShowDialog(this) == true)
                Tables.WriteXlsx(d.FileName, new[] { Tables.Labels, new[] { "close friend", "близкий друг", "best friend; good friend", "stranger", "She is a close friend.", "A person you know very well.", "adjective + noun", "Phrases & Expressions", "Relationships", "B1", "New", "Neutral", "No", "Are you close friends?", "Yes, we are." } });
        }
    }
}
