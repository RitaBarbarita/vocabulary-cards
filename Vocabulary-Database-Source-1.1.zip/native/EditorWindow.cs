using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace Vocab
{
    public sealed class EditorWindow : RetroWindow
    {
        readonly Store store;
        readonly LanguageChoice language;
        readonly Card original;
        public Card Draft;
        public readonly Dictionary<string, TextBox> TextFields = new Dictionary<string, TextBox>();
        public readonly Dictionary<string, ComboBox> Choices = new Dictionary<string, ComboBox>();
        readonly Dictionary<string, CheckBox> sections = new Dictionary<string, CheckBox>(), topics = new Dictionary<string, CheckBox>();
        readonly Dictionary<string, string> pendingImages = new Dictionary<string, string>();
        readonly StackPanel dialogPanel = new StackPanel(), attachmentPanel = new StackPanel(), sectionPanel = new StackPanel(), topicPanel = new StackPanel();
        readonly CheckBox fav = new CheckBox
        {
            Content = "Favorite"
        }, empty = new CheckBox
        {
            Content = "Only empty fields",
            IsChecked = true
        };
        readonly TextBox request = new TextBox
        {
            Margin = new Thickness(0, 4, 0, 6),
            MaxLength = 2000
        };
        readonly TextBlock aiStatus = Retro.Text("");
        readonly Button fill, stop, undo, save;
        CancellationTokenSource job;
        Dictionary<string, object> undoBefore, undoAfter;
        List<string> undoKeys;
        readonly System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(1)
        };
        DateTime started;
        public bool Saved { get; private set; }

        public bool Filling
        {
            get
            {
                return job != null;
            }
        }

        public EditorWindow(Store data, LanguageChoice chosen, Card card) : base(card == null ? "Add Card" : "Edit Card", 580, Math.Min(780, SystemParameters.WorkArea.Height - 30), true)
        {
            store = data;
            language = chosen;
            original = card;
            Draft = card == null ? new Card() : card.Copy();
            Draft.Normalize();
            var dock = new DockPanel();
            var footer = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(8)
            };
            save = Retro.Button("Save", "save", () => Save());
            footer.Children.Add(save);
            footer.Children.Add(Retro.Button("Cancel", null, () => Close()));
            DockPanel.SetDock(footer, Dock.Bottom);
            dock.Children.Add(footer);
            var body = new StackPanel
            {
                Margin = new Thickness(10)
            };
            var ai = new StackPanel
            {
                Margin = new Thickness(8)
            };
            ai.Children.Add(Retro.Row(Retro.Icon("ai"), Retro.Text("AI assistant · optional instructions")));
            ai.Children.Add(request);
            fill = Retro.Button("Fill", "ai", () =>
            {
                Generate();
            });
            stop = Retro.Button("Stop", null, () => Cancel());
            stop.Visibility = Visibility.Collapsed;
            undo = Retro.Button("Undo fill", null, () => Undo());
            undo.Visibility = Visibility.Collapsed;
            ai.Children.Add(Retro.Row(fill, stop, undo, empty));
            aiStatus.Text = "Translation & explanation: " + chosen.Name + ".";
            aiStatus.FontSize = 11;
            aiStatus.Margin = new Thickness(0, 6, 0, 0);
            ai.Children.Add(aiStatus);
            var setup = Retro.Button("Set up AI", null, () => new PrepareWindow().ShowDialog());
            if (!LocalApp.RuntimeReady || !LocalApp.ModelOnDisk)
            {
                setup.HorizontalAlignment = HorizontalAlignment.Left;
                setup.Margin = new Thickness(0, 5, 0, 0);
                ai.Children.Add(setup);
            }

            body.Children.Add(Retro.Frame(ai, true, new SolidColorBrush(Color.FromRgb(232, 232, 237))));
            body.Children.Add(Retro.Heading("Main"));
            AddText(body, "english", "Word or Phrase *", false);
            AddText(body, "russian", "Translation", false);
            AddText(body, "explanation", "Explanation", true);
            AddText(body, "example", "Example", true);
            var relations = new Grid();
            relations.ColumnDefinitions.Add(new ColumnDefinition());
            relations.ColumnDefinitions.Add(new ColumnDefinition());
            var syn = new StackPanel
            {
                Margin = new Thickness(0, 0, 5, 0)
            };
            var ant = new StackPanel
            {
                Margin = new Thickness(5, 0, 0, 0)
            };
            AddText(syn, "synonyms", "Synonyms / Similar", true);
            AddText(ant, "antonyms", "Antonyms / Opposite", true);
            Grid.SetColumn(ant, 1);
            relations.Children.Add(syn);
            relations.Children.Add(ant);
            body.Children.Add(relations);
            AddText(body, "grammar", "Grammar note", true);
            body.Children.Add(Retro.Heading("Dialogues (A: / B:)", "dialog"));
            body.Children.Add(Retro.Frame(dialogPanel, true, Brushes.White));
            RenderDialogs();
            var da = Retro.Row(Retro.Button("Add dialogue", "add", () =>
            {
                Capture();
                if (Draft.dialogs.Count == 0)
                    Draft.dialogs.Add(new Dialogue());
                var d = Draft.dialogs.Last();
                d.lines.Add(new Line { speaker = d.lines.Count % 2 == 0 ? "A" : "B", text = "" });
                RenderDialogs();
            }), Retro.Button("New dialogue", "add", () =>
            {
                Capture();
                Draft.dialogs.Add(new Dialogue { lines = new List<Line> { new Line(), new Line { speaker = "B" } } });
                RenderDialogs();
            }));
            da.Margin = new Thickness(0, 4, 0, 0);
            body.Children.Add(da);
            body.Children.Add(Retro.Heading("Attached images", "attach"));
            body.Children.Add(Retro.Text("Add screenshots or associations for this card.", false, 11, Brushes.Gray));
            var attach = Retro.Button("Add images", "image", () => AddImages());
            attach.HorizontalAlignment = HorizontalAlignment.Left;
            attach.Margin = new Thickness(0, 5, 0, 5);
            body.Children.Add(attach);
            body.Children.Add(attachmentPanel);
            RenderAttachments();
            body.Children.Add(Retro.Heading("Meta"));
            AddChoice(body, "register", "Register", Defaults.Registers);
            AddChoice(body, "level", "Level", Defaults.Levels);
            AddChoice(body, "status", "Status", Defaults.Statuses);
            fav.IsChecked = Draft.favorite;
            body.Children.Add(fav);
            body.Children.Add(Retro.Heading("Sections"));
            sectionPanel.Name = "SectionChoices";
            sectionPanel.Margin = new Thickness(7);
            body.Children.Add(Retro.Frame(sectionPanel, true, Brushes.White));
            AddTagRow(body, "section");
            body.Children.Add(Retro.Heading("Topics"));
            topicPanel.Name = "TopicChoices";
            topicPanel.Margin = new Thickness(7);
            body.Children.Add(Retro.Frame(topicPanel, true, Brushes.White));
            AddTagRow(body, "topic");
            RenderTags();
            dock.Children.Add(new ScrollViewer { Content = body, VerticalScrollBarVisibility = ScrollBarVisibility.Auto });
            Body = dock;
            timer.Tick += (s, e) => aiStatus.Text = "Filling card… " + (int)(DateTime.UtcNow - started).TotalSeconds + " s" + ((DateTime.UtcNow - started).TotalSeconds > 20 ? ". The first request may take longer." : "");
            Closing += (s, e) => Cancel();
            PreviewKeyDown += (s, e) =>
            {
                if (e.Key == System.Windows.Input.Key.S && System.Windows.Input.Keyboard.Modifiers == System.Windows.Input.ModifierKeys.Control)
                {
                    if (job == null)
                        Save();
                    e.Handled = true;
                }
            };
        }

        void AddText(Panel panel, string key, string label, bool multiline)
        {
            panel.Children.Add(new TextBlock { Text = label, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(64, 64, 64)), Margin = new Thickness(0, 7, 0, 4) });
            var value = typeof(Card).GetProperty(key).GetValue(Draft, null) as string;
            var box = new TextBox
            {
                Text = value ?? "",
                AcceptsReturn = multiline,
                TextWrapping = multiline ? TextWrapping.Wrap : TextWrapping.NoWrap,
                MinHeight = multiline ? 48 : 24,
                VerticalScrollBarVisibility = multiline ? ScrollBarVisibility.Auto : ScrollBarVisibility.Hidden
            };
            TextFields[key] = box;
            panel.Children.Add(box);
        }

        void AddChoice(Panel p, string key, string label, string[] values)
        {
            var row = new Grid
            {
                Margin = new Thickness(0, 5, 0, 0)
            };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) });
            row.ColumnDefinitions.Add(new ColumnDefinition());
            row.Children.Add(Retro.Text(label, true));
            var box = new ComboBox
            {
                ItemsSource = values.Select(v => new Choice { Value = v, Label = key == "status" ? Defaults.Status(v) : v == "" ? "—" : v }).ToList(),
                DisplayMemberPath = "Label",
                SelectedValuePath = "Value"
            };
            box.SelectedValue = Convert.ToString(typeof(Card).GetProperty(key).GetValue(Draft, null));
            if (box.SelectedItem == null)
                box.SelectedIndex = 0;
            Grid.SetColumn(box, 1);
            row.Children.Add(box);
            Choices[key] = box;
            p.Children.Add(row);
        }

        void AddTagRow(Panel p, string kind)
        {
            var input = new TextBox
            {
                Width = 210,
                Margin = new Thickness(0, 0, 4, 0)
            };
            var row = Retro.Row(input, Retro.Button("Add", null, () =>
            {
                Capture();
                var name = input.Text.Trim();
                if (name.Length == 0)
                    return;
                var all = kind == "section" ? store.Sections() : store.Topics();
                if (!all.Contains(name))
                    (kind == "section" ? store.Data.settings.customSections : store.Data.settings.customTopics).Add(name);
                (kind == "section" ? Draft.sections : Draft.topics).Add(name);
                store.Save();
                RenderTags();
                input.Text = "";
            }));
            row.Margin = new Thickness(0, 4, 0, 0);
            p.Children.Add(row);
        }

        void RenderTags()
        {
            foreach (var kind in new[]
            {
                "section",
                "topic"
            })
            {
                var target = kind == "section" ? sectionPanel : topicPanel;
                var dict = kind == "section" ? sections : topics;
                target.Children.Clear();
                dict.Clear();
                var wrap = new WrapPanel();
                foreach (var value in kind == "section" ? store.Sections() : store.Topics())
                {
                    var c = new CheckBox
                    {
                        Content = value,
                        IsChecked = (kind == "section" ? Draft.sections : Draft.topics).Contains(value),
                        Margin = new Thickness(0, 3, 10, 3)
                    };
                    dict[value] = c;
                    wrap.Children.Add(c);
                }

                target.Children.Add(wrap);
            }
        }

        public Card Capture()
        {
            foreach (var pair in TextFields)
                typeof(Card).GetProperty(pair.Key).SetValue(Draft, pair.Value.Text, null);
            foreach (var pair in Choices)
                typeof(Card).GetProperty(pair.Key).SetValue(Draft, Convert.ToString(pair.Value.SelectedValue), null);
            Draft.favorite = fav.IsChecked == true;
            Draft.sections = sections.Where(p => p.Value.IsChecked == true).Select(p => p.Key).ToList();
            Draft.topics = topics.Where(p => p.Value.IsChecked == true).Select(p => p.Key).ToList();
            return Draft;
        }

        public void ApplyField(string key, object value)
        {
            if (TextFields.ContainsKey(key))
                TextFields[key].Text = Convert.ToString(value);
            else if (Choices.ContainsKey(key))
                Choices[key].SelectedValue = Convert.ToString(value);
            else if (key == "sections")
            {
                Draft.sections = Json.Read<List<string>>(Json.Write(value));
                RenderTags();
            }
            else if (key == "topics")
            {
                Draft.topics = Json.Read<List<string>>(Json.Write(value));
                RenderTags();
            }
            else if (key == "dialogs")
            {
                Draft.dialogs = Json.Read<List<Dialogue>>(Json.Write(value));
                RenderDialogs();
            }
        }

        void RenderDialogs()
        {
            dialogPanel.Children.Clear();
            if (Draft.dialogs.Count == 0)
            {
                dialogPanel.Children.Add(new TextBlock { Text = "No dialogues yet. Click New dialogue to start.", Foreground = Brushes.Gray, Margin = new Thickness(8) });
                return;
            }

            for (int group = 0; group < Draft.dialogs.Count; group++)
            {
                int gi = group;
                var d = Draft.dialogs[group];
                var p = new StackPanel
                {
                    Margin = new Thickness(7)
                };
                var head = new DockPanel();
                var remove = Retro.Button("Remove dialogue", null, () =>
                {
                    Draft.dialogs.RemoveAt(gi);
                    RenderDialogs();
                });
                remove.Foreground = Brushes.Maroon;
                DockPanel.SetDock(remove, Dock.Right);
                head.Children.Add(remove);
                head.Children.Add(Retro.Text("Dialogue " + (group + 1), true));
                p.Children.Add(head);
                for (int i = 0; i < d.lines.Count; i++)
                {
                    int li = i;
                    var line = d.lines[i];
                    line.speaker = i % 2 == 0 ? "A" : "B";
                    var row = new Grid
                    {
                        Margin = new Thickness(0, 3, 0, 0)
                    };
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(25) });
                    row.ColumnDefinitions.Add(new ColumnDefinition());
                    row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(26) });
                    row.Children.Add(Retro.Text(line.speaker + ":", true, 12, line.speaker == "B" ? Brushes.Maroon : Retro.Navy));
                    var field = new TextBox
                    {
                        Text = line.text ?? "",
                        AcceptsReturn = true,
                        TextWrapping = TextWrapping.Wrap
                    };
                    field.TextChanged += (s, e) => line.text = field.Text;
                    Grid.SetColumn(field, 1);
                    row.Children.Add(field);
                    var del = Retro.Tiny("close", "Remove line", () =>
                    {
                        Draft.dialogs[gi].lines.RemoveAt(li);
                        if (Draft.dialogs[gi].lines.Count == 0)
                            Draft.dialogs.RemoveAt(gi);
                        RenderDialogs();
                    });
                    Grid.SetColumn(del, 2);
                    row.Children.Add(del);
                    p.Children.Add(row);
                }

                dialogPanel.Children.Add(p);
            }
        }

        void AddImages()
        {
            var files = new OpenFileDialog
            {
                Filter = "Images|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.webp;*.tif;*.tiff|All files|*.*",
                Multiselect = true
            };
            if (files.ShowDialog(this) == true)
                QueueImages(files.FileNames);
        }

        public void QueueImages(IEnumerable<string> files)
        {
            foreach (var file in files)
            {
                var a = new Attachment
                {
                    id = Guid.NewGuid().ToString("N"),
                    name = Path.GetFileName(file),
                    type = "image/" + Path.GetExtension(file).TrimStart('.'),
                    size = new FileInfo(file).Length
                };
                Draft.attachments.Add(a);
                pendingImages[a.id] = file;
            }

            RenderAttachments();
        }

        void RenderAttachments()
        {
            attachmentPanel.Children.Clear();
            if (Draft.attachments.Count == 0)
            {
                attachmentPanel.Children.Add(Retro.Text("No images attached.", false, 11, Brushes.Gray));
                return;
            }

            foreach (var a in Draft.attachments.ToList())
            {
                var row = new DockPanel
                {
                    Margin = new Thickness(0, 3, 0, 3)
                };
                var del = Retro.Tiny("delete", "Remove image", () =>
                {
                    Draft.attachments.Remove(a);
                    pendingImages.Remove(a.id);
                    RenderAttachments();
                });
                DockPanel.SetDock(del, Dock.Right);
                row.Children.Add(del);
                string file = pendingImages.ContainsKey(a.id) ? pendingImages[a.id] : store.ImagePath(a.id);
                try
                {
                    if (File.Exists(file))
                    {
                        var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                        bitmap.BeginInit();
                        bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                        bitmap.UriSource = new Uri(file);
                        bitmap.DecodePixelWidth = 160;
                        bitmap.EndInit();
                        var thumbnail = new Image
                        {
                            Source = bitmap,
                            Width = 80,
                            Height = 55,
                            Stretch = Stretch.Uniform,
                            Margin = new Thickness(0, 0, 7, 0)
                        };
                        row.Children.Add(thumbnail);
                    }
                }
                catch
                {
                }

                row.Children.Add(Retro.Text(a.name, false, 11));
                attachmentPanel.Children.Add(row);
            }
        }

        public void Save()
        {
            Capture();
            Draft.english = Draft.english.Trim();
            if (Draft.english.Length == 0)
            {
                Retro.Message("Word or Phrase is required.");
                TextFields["english"].Focus();
                return;
            }

            var candidate = Draft.Copy();
            candidate.dialogs = candidate.dialogs.Select(d => new Dialogue { lines = d.lines.Where(l => !String.IsNullOrWhiteSpace(l.text)).Select(l => new Line { speaker = l.speaker, text = l.text.Trim() }).ToList() }).Where(d => d.lines.Count > 0).ToList();
            foreach (var a in candidate.attachments)
                if (pendingImages.ContainsKey(a.id))
                    File.Copy(pendingImages[a.id], store.ImagePath(a.id), true);
            var previous = Json.Write(store.Data);
            try
            {
                int index = original == null ? -1 : store.Data.cards.FindIndex(c => c.id == original.id);
                if (index < 0)
                    store.Data.cards.Insert(0, candidate);
                else
                    store.Data.cards[index] = candidate;
                store.RegisterTags(candidate);
                store.Save();
            }
            catch
            {
                store.Data = Json.Read<Database>(previous);
                throw;
            }

            Saved = true;
            Close();
        }

        void Busy(bool value)
        {
            fill.IsEnabled = !value;
            save.IsEnabled = !value;
            stop.Visibility = value ? Visibility.Visible : Visibility.Collapsed;
            undo.IsEnabled = !value;
        }

        public void Cancel()
        {
            if (job == null)
                return;
            job.Cancel();
            job = null;
            timer.Stop();
            Busy(false);
            aiStatus.Text = "Fill cancelled.";
        }

        public void Undo()
        {
            if (undoKeys == null || job != null)
                return;
            var now = AI.Fields(Capture());
            foreach (var key in undoKeys)
                if (AI.Same(now[key], undoAfter[key]))
                    ApplyField(key, undoBefore[key]);
            undoKeys = null;
            undo.Visibility = Visibility.Collapsed;
            aiStatus.Text = "Fill undone. Later manual edits were kept.";
        }

        public bool ApplyResult(Dictionary<string, object> result, Dictionary<string, object> before, bool onlyEmpty)
        {
            var now = AI.Fields(Capture());
            if (!AI.Same(now["english"], before["english"]))
                throw new InvalidOperationException("The word changed while filling. Click Fill again.");
            var keys = result.Keys.Where(k => AI.Has(result[k]) && (!onlyEmpty || !AI.Has(before[k])) && AI.Same(now[k], before[k]) && !AI.Same(now[k], result[k])).ToList();
            if (keys.Count == 0)
                return false;
            undoBefore = now;
            undoAfter = result;
            undoKeys = keys;
            foreach (var key in keys)
                ApplyField(key, result[key]);
            undo.Visibility = Visibility.Visible;
            return true;
        }

        public async void Generate()
        {
            if (job != null)
                return;
            var before = AI.Fields(Capture());
            var current = Draft.Copy();
            bool onlyEmpty = empty.IsChecked == true;
            var own = new CancellationTokenSource(TimeSpan.FromMinutes(3));
            job = own;
            Busy(true);
            started = DateTime.UtcNow;
            timer.Start();
            aiStatus.Text = "Filling card…";
            try
            {
                var result = await AI.Generate(current, request.Text, store, language, own.Token);
                if (job != own)
                    return;
                if (!ApplyResult(result, before, onlyEmpty))
                {
                    aiStatus.Text = "Fields are already filled. Uncheck Only empty fields to replace them.";
                    return;
                }

                aiStatus.Text = "Done in " + (int)(DateTime.UtcNow - started).TotalSeconds + " s. Review the card and click Save.";
            }
            catch (OperationCanceledException)
            {
                if (job == own)
                    aiStatus.Text = "The request was stopped or timed out. Please try again.";
            }
            catch (Exception error)
            {
                if (job == own)
                    aiStatus.Text = error.Message;
            }
            finally
            {
                own.Dispose();
                if (job == own)
                {
                    job = null;
                    timer.Stop();
                    Busy(false);
                }
            }
        }
    }

    public sealed class Choice
    {
        public string Value { get; set; }
        public string Label { get; set; }

        public override string ToString()
        {
            return Label ?? "";
        }
    }
}
