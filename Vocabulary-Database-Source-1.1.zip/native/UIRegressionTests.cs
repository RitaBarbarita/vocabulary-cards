using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Input;
using System.Windows.Interop;
using System.Runtime.InteropServices;

namespace Vocab
{
    public static class UIRegressionTests
    {
        static List<string> checks = new List<string>();
        static void Check(bool value, string message)
        {
            if (!value)
                throw new Exception(message);
            checks.Add(message);
        }

        [StructLayout(LayoutKind.Sequential)]
        struct NativeRect
        {
            public int left, top, right, bottom;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct NativePoint
        {
            public int x, y;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct MonitorInfo
        {
            public int size;
            public NativeRect monitor, work;
            public uint flags;
        }

        [DllImport("user32.dll")]
        static extern bool GetWindowRect(IntPtr window, out NativeRect rect);
        [DllImport("user32.dll")]
        static extern bool ClientToScreen(IntPtr window, ref NativePoint point);
        [DllImport("user32.dll")]
        static extern IntPtr MonitorFromWindow(IntPtr window, uint flags);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);
        public static IEnumerable<T> Find<T>(DependencyObject root)
            where T : DependencyObject
        {
            if (root is T)
                yield return (T)root;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
                foreach (var child in Find<T>(VisualTreeHelper.GetChild(root, i)))
                    yield return child;
        }

        public static void Pump()
        {
            var frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.ContextIdle, new Action(() => frame.Continue = false));
            Dispatcher.PushFrame(frame);
        }

        public static int Run(string output)
        {
            Directory.CreateDirectory(output);
            try
            {
                var store = new Store(Path.Combine(output, "ui-data-" + Guid.NewGuid().ToString("N")));
                var language = AIPreferences.Languages().First(l => l.Code == "en");
                var editor = new EditorWindow(store, language, null);
                NativeTests.ShowOffscreen(editor);
                foreach (var pair in editor.Choices)
                {
                    var box = pair.Value;
                    box.BringIntoView();
                    Pump();
                    box.ApplyTemplate();
                    var popup = (Popup)box.Template.FindName("PART_Popup", box);
                    popup.Child.Opacity = 0;
                    var toggle = (ToggleButton)box.Template.FindName("DropDownToggle", box);
                    Check(toggle.ClickMode == ClickMode.Press, pair.Key + " dropdown opens on press without capturing the following item click");
                    typeof(ToggleButton).GetMethod("OnClick", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).Invoke(toggle, null);
                    Pump();
                    Check(box.IsDropDownOpen, pair.Key + " arrow opens the menu");
                    popup.Child.UpdateLayout();
                    var containers = Enumerable.Range(0, box.Items.Count).Select(i => box.ItemContainerGenerator.ContainerFromIndex(i) as ComboBoxItem).ToArray();
                    Check(containers.All(i => i != null && i.ActualHeight > 0), pair.Key + " dropdown displays all options");
                    Check(containers.SelectMany(i => Find<TextBlock>(i)).Any(t => !String.IsNullOrEmpty(t.Text)), pair.Key + " dropdown labels are visible");
                    containers.Last().RaiseEvent(new MouseButtonEventArgs(Mouse.PrimaryDevice, Environment.TickCount, MouseButton.Left) { RoutedEvent = Mouse.MouseUpEvent });
                    Check(Convert.ToString(box.SelectedValue) != "" && !box.IsDropDownOpen, pair.Key + " item click selects and closes the menu");
                }

                Check(editor.Capture().level == "C1" && editor.Capture().status == "known" && editor.Capture().register == "Slang", "Native editor captures the chosen level, status and register");
                editor.TextFields["english"].Text = "Choice persistence";
                editor.Save();
                var saved = new Store(store.Root).Data.cards.Single();
                Check(saved.level == "C1" && saved.status == "known" && saved.register == "Slang", "Selected metadata persists after Save");
                var edit = new EditorWindow(store, language, store.Data.cards[0]);
                NativeTests.ShowOffscreen(edit);
                foreach (var pair in edit.Choices)
                {
                    var box = pair.Value;
                    box.BringIntoView();
                    Pump();
                    box.ApplyTemplate();
                    var popup = (Popup)box.Template.FindName("PART_Popup", box);
                    popup.Child.Opacity = 0;
                    for (int i = 0; i < box.Items.Count; i++)
                    {
                        var toggle = (ToggleButton)box.Template.FindName("DropDownToggle", box);
                        typeof(ToggleButton).GetMethod("OnClick", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic).Invoke(toggle, null);
                        Pump();
                        var item = (ComboBoxItem)box.ItemContainerGenerator.ContainerFromIndex(i);
                        item.RaiseEvent(new MouseButtonEventArgs(Mouse.PrimaryDevice, Environment.TickCount, MouseButton.Left) { RoutedEvent = Mouse.MouseUpEvent });
                        Pump();
                        Check(Convert.ToString(box.SelectedValue) == ((Choice)box.Items[i]).Value && !box.IsDropDownOpen && Find<TextBlock>(box).Any(t => t.Text == ((Choice)box.Items[i]).Label), "Editing can select and display " + pair.Key + " / " + ((Choice)box.Items[i]).Label);
                    }
                }

                var editorScroll = Find<ScrollViewer>(edit).First(s => s.Content is StackPanel);
                editorScroll.ScrollToEnd();
                Pump();
                NativeTests.Screenshot(edit, Path.Combine(output, "Metadata-and-tags.png"));
                edit.Close();
                var categoryPanels = Find<StackPanel>(editor).Where(p => p.Name == "SectionChoices" || p.Name == "TopicChoices").ToArray();
                Check(categoryPanels.Length == 2 && categoryPanels.All(p => ((Border)((Border)p.Parent).Parent).Background == Brushes.White), "Section and topic checkboxes have white inset panels");
                for (int i = 0; i < 120; i++)
                    store.Data.cards.Add(new Card { english = "Card " + i, russian = "Translation", example = "An example sentence.", level = "B1" });
                var main = new MainWindow(store, language);
                NativeTests.ShowOffscreen(main);
                Pump();
                var scroll = Find<ScrollViewer>(main).Single(s => s.Name == "CardScroll");
                var cards = Find<CenteredCardsPanel>(main).Single();
                main.Width = 2100;
                main.UpdateLayout();
                var positions = cards.Children.Cast<FrameworkElement>().Select(c => new { element = c, p = c.TranslatePoint(new Point(), cards) }).GroupBy(c => Math.Round(c.p.Y)).ToArray();
                Check(positions.All(row => Math.Abs(row.Min(p => p.p.X) - (cards.ActualWidth - row.Max(p => p.p.X + p.element.ActualWidth))) < 2), "Card rows center after resizing the native window");
                var partial = new CenteredCardsPanel();
                for (int i = 0; i < 7; i++)
                    partial.Children.Add(new Border { Width = 335, Height = 100, Margin = new Thickness(3.5, 0, 3.5, 7) });
                partial.Measure(new Size(1100, Double.PositiveInfinity));
                partial.Arrange(new Rect(0, 0, 1100, partial.DesiredSize.Height));
                var partialRows = partial.Children.Cast<FrameworkElement>().Select(c => new { element = c, p = c.TranslatePoint(new Point(), partial) }).GroupBy(c => Math.Round(c.p.Y)).ToArray();
                Check(partialRows.First().Count() == 3 && partialRows.Last().Count() == 1 && partialRows.All(row => Math.Abs(row.Min(p => p.p.X) - (partial.ActualWidth - row.Max(p => p.p.X + p.element.ActualWidth))) < 2), "An incomplete last row is centered as well as full rows");
                main.Width = 1500;
                main.UpdateLayout();
                scroll.ScrollToEnd();
                Pump();
                double oldOffset = scroll.VerticalOffset;
                var firstCard = cards.Children[0];
                var more = Find<Button>(main).Single(b => b.Name == "MoreCards");
                more.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                Pump();
                Check(cards.Children.Count == 96 && ReferenceEquals(firstCard, cards.Children[0]) && Math.Abs(scroll.VerticalOffset - oldOffset) < 1, "Show more appends cards without replacing the list or changing the scroll position");
                var top = Find<Button>(main).Single(b => b.Name == "BackToTop");
                Check(top.Visibility == Visibility.Visible, "Back to top appears after scrolling");
                NativeTests.Screenshot(main, Path.Combine(output, "Back-to-top.png"));
                top.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                Pump();
                Check(scroll.VerticalOffset == 0 && top.Visibility == Visibility.Collapsed, "Back to top returns to the first cards and hides");
                NativeTests.Screenshot(main, Path.Combine(output, "Centered-cards.png"));
                var captionButtons = Find<Button>(main).Where(b => b.Name.StartsWith("Caption")).ToArray();
                Check(captionButtons.Length == 3 && captionButtons.All(b => ((Image)b.Content).Margin == new Thickness(0) && ((Image)b.Content).ActualWidth == 16 && ((Image)b.Content).ActualHeight == 16), "Close, minimize and maximize graphics fit their buttons without clipping");
                NativeRect outer;
                var hwnd = new WindowInteropHelper(main).Handle;
                GetWindowRect(hwnd, out outer);
                var client = new NativePoint();
                ClientToScreen(hwnd, ref client);
                Check(client.y - outer.top < 2, "There is no native white strip above the custom title bar");
                main.Opacity = 0;
                var maximize = captionButtons.Single(b => b.Name == "CaptionMaximize");
                maximize.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                Pump();
                main.UpdateLayout();
                Check(main.WindowState == WindowState.Maximized, "Maximize button expands the native window");
                var monitor = new MonitorInfo
                {
                    size = Marshal.SizeOf(typeof(MonitorInfo))
                };
                GetMonitorInfo(MonitorFromWindow(hwnd, 2), ref monitor);
                var root = (FrameworkElement)main.Content;
                var tl = root.PointToScreen(new Point());
                var br = root.PointToScreen(new Point(root.ActualWidth, root.ActualHeight));
                File.WriteAllText(Path.Combine(output, "maximized-bounds.json"), Json.Write(new { visual = new { left = tl.X, top = tl.Y, right = br.X, bottom = br.Y }, work = monitor.work }));
                Check(tl.X >= monitor.work.left - 1 && tl.Y >= monitor.work.top - 1 && br.X <= monitor.work.right + 1 && br.Y <= monitor.work.bottom + 1, "Maximized content stays inside the monitor work area above the taskbar");
                NativeTests.Screenshot(main, Path.Combine(output, "Maximized-layout.png"));
                maximize.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                Pump();
                Check(main.WindowState == WindowState.Normal, "Maximize button restores the original window size");
                captionButtons.Single(b => b.Name == "CaptionMinimize").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                Pump();
                Check(main.WindowState == WindowState.Minimized, "Minimize button minimizes the native window");
                SystemCommands.RestoreWindow(main);
                Pump();
                bool closed = false;
                main.Closed += (s, e) => closed = true;
                captionButtons.Single(b => b.Name == "CaptionClose").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                Pump();
                Check(closed, "Close button closes the native window");
                var tag = CardView.Tags(new Card { status = "new" });
                Check(((Border)tag.Children[0]).Background == Brushes.Maroon, "New status uses the original dark red color");
                var exampleCard = new Card
                {
                    example = "First example.\nSecond example.\nThird example.",
                    dialogs = new List<Dialogue>
                    {
                        new Dialogue
                        {
                            lines = new List<Line>
                            {
                                new Line
                                {
                                    text = "A line"
                                },
                                new Line
                                {
                                    speaker = "B",
                                    text = "B line"
                                }
                            }
                        }
                    }
                };
                var examples = CardView.Examples(exampleCard);
                Check(examples.Children.OfType<DottedDivider>().Count() == 3, "Faint dashed lines separate example rows and the dialogue");
                Retro.SavePng(CardView.Content(store, exampleCard, true), Path.Combine(output, "Separated-examples.png"), 600, 2);
                Check(Find<DottedDivider>(CardView.Content(store, exampleCard)).Count() == 3, "Details and PNG export share the same separators");
                File.WriteAllText(Path.Combine(output, "ui-regression-results.json"), Json.Write(new { passed = checks.Count, checks = checks }));
                return 0;
            }
            catch (Exception error)
            {
                File.WriteAllText(Path.Combine(output, "ui-regression-error.txt"), error.ToString());
                return 1;
            }
        }
    }
}
